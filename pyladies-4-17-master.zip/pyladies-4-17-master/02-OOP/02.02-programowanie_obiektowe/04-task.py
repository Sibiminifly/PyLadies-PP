'''
    Twoim zadaniem jest stworzenie programu do zarządzania
    księgarnią - bez wątpienia przydałaby się w nim klasa 
    reprezentująca książki. Zastanów się jak moglaby wyglądać, 
    a następnie zaimplementuj ją w tym pliku (nie zapomnij o 
    konstruktorze!). Na koniec stwórz w pętli 3 instancji tej 
    klasy wykorzystując dane we wcześniej przygotowanejliście
    słowników (podobnej do listy z pliku 01) i **kwargsy.
    Każdą z tych instancji dołącz do listy, po czym przeiteruj się
    po tej liście i dla każdej ksiązki wyprintuj jej tytuł.
'''
