'''
    Skopiuj kod z poprzedniego zadania. Do klasy Book dodaj
    atrybut klasowy books będący listą. Zmodyfikuj konstruktor,
    tak aby dodawać do niego każdy nowo tworzony obiekt klasy Book.
    Zmodyfikuj pętlę, tak żeby korzystać z nowo powstałej listy
    - atrybutu klasy.
'''
