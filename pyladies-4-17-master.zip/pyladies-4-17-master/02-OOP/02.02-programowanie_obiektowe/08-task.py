'''
    Skopiuj tutaj kod z rozwiązania zadania z pliku 06, 
    a następnie zmodyfikuj go dodając do klasy Book metodę
    is_available(), która zwróci wartość logiczną w zależności
    od tego, czy dostępne są egzemplarze danej ksiązki.
    W pętli printującej reprezentację tekstową książki zmień kod tak,
    aby na ekranie pojawiła się informacja o dostępności danej ksiązki.
'''
