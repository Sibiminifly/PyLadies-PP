# pyladies-4-17

# Dokonałeś zmian w kodzie i nie chcesz ich stracić?

# W folderze z repozytorium wpisz:

* git checkout -b moje-zmiany
* git add .
* git commit -m'Moje zmiany w plikach'
* git checkout master
* git reset --hard
* git pull
