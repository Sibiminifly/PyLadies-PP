'''
    Przykładowe funkcje, będące 'mięsem' naszej biblioteki
'''


def calculate_first_n_prime_numbers(n=1):
    '''
        Calculates first n prime numbers 
        using some super-duper methods ;)
    '''
    pass


def calculate_first_n_pi_digits(n=1):
    '''
        Calculates first n PI digits 
        using some super-duper methods ;)
    '''
    pass
