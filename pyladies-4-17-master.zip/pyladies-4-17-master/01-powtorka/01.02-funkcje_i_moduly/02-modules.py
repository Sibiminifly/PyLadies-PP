'''
    Dzięki dodatkowemu importowaniu w pliku __init__.py 
    nie musimy się odwoływać poprzez module.base
'''
from module import (
    calculate_first_n_pi_digits,
    calculate_first_n_prime_numbers,
)
