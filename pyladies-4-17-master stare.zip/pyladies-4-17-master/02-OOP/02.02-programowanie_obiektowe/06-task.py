'''
    Skopiuj tutaj kod z rozwiązania zadania 04, a następnie 
    zmodyfikuj go dodając czytelną tekstową reprezentację 
    obiektu w formacie:
    '<book.title> by <book.author>'
    W pętli printującej tytuł książki zmień kod tak, aby 
    na ekranie pojawiła się zaimplementowana reprezentacja 
    tekstowa.
'''
